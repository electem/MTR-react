import styled from 'styled-components';

const MessageContent = styled.p`
  display: inline-block;
  font-size: 13px;
`;

export default MessageContent;
