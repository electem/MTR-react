import styled from 'styled-components';
import { palette } from 'styled-theme';

const RatingStyleWrapper = styled.div``;

export default RatingStyleWrapper;
