// import React from 'react';
// import { Collapse } from 'antd';
// import { CollapseStyleWrapper } from './collapse.style';
//
// const Panel = Collapse.Panel;
// export { Panel };
// export default props =>
//   <CollapseStyleWrapper>
//     <Collapse {...props}>
//       {props.children}
//     </Collapse>
//   </CollapseStyleWrapper>;

import { Collapse } from 'antd';

export default Collapse;
