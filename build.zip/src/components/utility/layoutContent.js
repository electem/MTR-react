import LayoutContentStyle from './layoutContent.style';

export default LayoutContentStyle;
