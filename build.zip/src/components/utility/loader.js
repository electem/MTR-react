import React from 'react';

export default Loader =>
  <div className="isoContentLoader">
    <div className="loaderElement" />
  </div>;
