# Isomorphic - React Redux Admin Dashboard `Version 2.4.0`

### Please check `src/config.js` & edit as your app.

Installation Guide:
https://redq.gitbooks.io/isomorphic/content/

Demo page:
https://isomorphic.redq.io/
